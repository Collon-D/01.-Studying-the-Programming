#include "CObject.h"

CObject::CObject()
    : m_vPos {}
    , m_vScale {}
{

}

CObject::~CObject()
{

}
