#include <Windows.h>


#define SINGLE(type) static type* GetInst() \
                    {\
                     static type mgr; \
                     return &mgr; \
                    }
