#include "define.h"

class CCore
{
private:
    HWND    m_hwnd;
    POINT   m_ptResoulution;
    HDC     m_hdc;
public:
    SINGLE(CCore);

public:
    int Init(HWND _hwnd, POINT _ptResoulution);
    void progress();

private:
    void update();
    void render();

private:
    CCore();
    ~CCore();
};
