#include "define.h"

class CCore
{
private:
    HWND    m_hwnd;
    POINT   m_ptResoulution;

public:
    SINGLE(CCore);

public:
    int Init(HWND _hwnd, POINT _ptResoulution);
    void progress();

private:
    CCore();
    ~CCore();
};
