#include "Core.h"
#include "CObject.h"
#include "define.h"
#include "CTimeMgr.h"
#include "CKeyMgr.h"

CObject g_obj;

CCore::CCore()
    : m_hwnd(0)
    , m_ptResoulution{}
    , m_hdc(0)
    , m_hbit(0)
    , m_memDC(0)

{

}

CCore::~CCore()
{
    ReleaseDC(m_hwnd, m_hdc);

    DeleteDC(m_memDC);
    DeleteObject(m_hbit);
}

int CCore::Init(HWND _hwnd, POINT _ptResoulution)
{
    m_hwnd = _hwnd;
    m_ptResoulution = _ptResoulution;

    RECT rt = {0, 0, _ptResoulution.x, _ptResoulution.y};

    // �ػ󵵿� �°� ������ ũ�� ����
    AdjustWindowRect(&rt, WS_OVERLAPPED, false);
    SetWindowPos(m_hwnd, nullptr, 100, 100, rt.right - rt.left, rt.bottom - rt.top, 0);

    m_hdc = GetDC(m_hwnd);
    SetDCPenColor(m_hdc, RGB(255, 0, 0));

    m_hbit = CreateCompatibleBitmap(m_hdc, m_ptResoulution.x, m_ptResoulution.y);
    m_memDC = CreateCompatibleDC(m_hdc);

    HBITMAP hOldBit = (HBITMAP)SelectObject(m_memDC, m_hbit);
    DeleteObject(hOldBit);


    CTimeMgr::GetInst()->Init();
    CKeyMgr::GetInst()->Init();

    g_obj.SetPos(Vec2((float)(m_ptResoulution.x / 2), (float)(m_ptResoulution.y / 2)));
    g_obj.SetScale(Vec2(100, 100));

    return S_OK;
}

void CCore::progress()
{
    // Mgr Update
    CTimeMgr::GetInst()->Update();
    CKeyMgr::GetInst()->Update();

    update();

    render();
}

void CCore::update()
{
    Vec2 vPos = g_obj.GetPos();

    if (CKeyMgr::GetInst()->GetKeyState(KEY::LEFT) == KEY_STATE::HOLD)
    {
        vPos.x -= 100.f * fDT;
    }
    else if (CKeyMgr::GetInst()->GetKeyState(KEY::RIGHT) == KEY_STATE::HOLD)
    {
        vPos.x += 100.f * fDT;
    }
    else if (CKeyMgr::GetInst()->GetKeyState(KEY::UP) == KEY_STATE::HOLD)
    {
        vPos.y -= 100.f * fDT;
    }
    else if (CKeyMgr::GetInst()->GetKeyState(KEY::DOWN) == KEY_STATE::HOLD)
    {
        vPos.y += 100.f * fDT;
    }


    g_obj.SetPos(vPos);
}

void CCore::render()
{
    Rectangle(m_memDC, -1, -1, m_ptResoulution.x + 1, m_ptResoulution.y + 1);

    Vec2 vPos = g_obj.GetPos();
    Vec2 vScale = g_obj.GetScale();

    Rectangle(m_memDC, vPos.x - vScale.x / 2
              , vPos.y - vScale.y / 2
              , vPos.x + vScale.x / 2
              , vPos.y + vScale.y / 2);

    BitBlt(m_hdc, 0, 0, m_ptResoulution.x, m_ptResoulution.y
           , m_memDC, 0, 0, SRCCOPY);
}
