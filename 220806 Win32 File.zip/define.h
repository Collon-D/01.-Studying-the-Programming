
#include <Windows.h>
#include <vector>
using std::vector;

#define SINGLE(type) static type* GetInst() \
                    {\
                     static type mgr; \
                     return &mgr; \
                    }


#define fDT CTimeMgr::GetInst()->GetfDT()
#define DT  CTimeMgr::GetInst()->GetDT()
