#include "CObject.h"

CObject::CObject()
{

}

CObject::~CObject()
{

}
