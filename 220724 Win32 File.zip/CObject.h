#include "define.h"

class CObject
{
public:
    POINT   m_ptPos;
    POINT   m_ptScale;

public:
    CObject();
    ~CObject();
};
