#include "Core.h"
#include "CObject.h"
#include "define.h"

CObject g_obj;

CCore::CCore()
    : m_hwnd(0)
    , m_ptResoulution{}
    , m_hdc(0)

{

}

CCore::~CCore()
{
    ReleaseDC(m_hwnd, m_hdc);
}

int CCore::Init(HWND _hwnd, POINT _ptResoulution)
{
    m_hwnd = _hwnd;
    m_ptResoulution = _ptResoulution;

    RECT rt = {0, 0, _ptResoulution.x, _ptResoulution.y};

    // �ػ󵵿� �°� ������ ũ�� ����
    AdjustWindowRect(&rt, WS_OVERLAPPED, false);
    SetWindowPos(m_hwnd, nullptr, 100, 100, rt.right - rt.left, rt.bottom - rt.top, 0);

    m_hdc = GetDC(m_hwnd);
    SetDCPenColor(m_hdc, RGB(255, 0, 0));


    g_obj.m_ptPos = POINT{ m_ptResoulution.x / 2, m_ptResoulution.y / 2};
    g_obj.m_ptScale = POINT { 100, 100 };

    return S_OK;
}

void CCore::progress() {

    update();

    render();
}

void CCore::update()
{
    if (GetAsyncKeyState(VK_LEFT) & 0x8000)
    {
        g_obj.m_ptPos.x -= 1;
    }
    else if (GetAsyncKeyState(VK_RIGHT) & 0x8000)
    {
        g_obj.m_ptPos.x += 1;
    }
}

void CCore::render()
{
    Rectangle(m_hdc, g_obj.m_ptPos.x - g_obj.m_ptScale.x / 2
              , g_obj.m_ptPos.y - g_obj.m_ptScale.y / 2
              , g_obj.m_ptPos.x + g_obj.m_ptScale.x / 2
              , g_obj.m_ptPos.y + g_obj.m_ptScale.y / 2);
}
